# Personal Introduction Program

## Project Overview
This is a simple Python program that asks the user for personal information and displays a friendly welcome message.

## What I Learned
- Installing Python
- Using input() and print()
- Storing data in variables
- Writing a basic Python program

## Setup Instructions
1. Install Python from python.org
2. Open terminal
3. Run: python personal_intro.py

## Output
The program asks for user details and displays a personalized welcome message.
